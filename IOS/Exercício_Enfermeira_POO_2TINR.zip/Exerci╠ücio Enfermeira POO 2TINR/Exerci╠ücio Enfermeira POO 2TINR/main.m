//
//  main.m
//  Exercício Enfermeira POO 2TINR
//
//  Created by Usuário Convidado on 20/03/17.
//  Copyright © 2017 Agesandro Scarpioni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Enfermeira.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Enfermeira *e = [[Enfermeira alloc]init];
        [e setNome:@"Carlos Rodrigues"];
        [e setSalario:5888];
        [e setPlantao:YES];
        [e setCoren:123456];
        
        NSLog(@"Enfermeiro %@ - Coren %d", [e getNome], [e getCoren]);
        //modelo com if ternário
        NSLog(@"Salário atual %0.2f - Plantonista %@", [e getSalario], [e getPlantao]? @"SIM":@"NÃO");
        //modelo com if composto
        if ([e getPlantao]) {
            NSLog(@"Plantonista: SIM");
        }else{
             NSLog(@"Plantonista: NÃO");
        }
        
        
            }
    return 0;
}
