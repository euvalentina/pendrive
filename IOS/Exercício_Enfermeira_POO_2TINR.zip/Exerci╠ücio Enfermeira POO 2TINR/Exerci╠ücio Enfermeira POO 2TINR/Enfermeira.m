//
//  Enfermeira.m
//  Exercício Enfermeira POO 2TINR
//
//  Created by Usuário Convidado on 20/03/17.
//  Copyright © 2017 Agesandro Scarpioni. All rights reserved.
//

#import "Enfermeira.h"

@implementation Enfermeira

-(void)setNome:(NSString *)_nome{
    nome=_nome;
}
-(NSString *)getNome{
    return nome;
}
-(void)setCoren:(int)_coren{
    coren=_coren;
}
-(int)getCoren{
    return coren;
}
-(void)setSalario:(float)_salario{
    salario=_salario;
}
-(float)getSalario{
    return salario;
}
-(void)setPlantao:(BOOL)_plantao{
    plantao=_plantao;
}
-(BOOL)getPlantao{
    return plantao;
}

@end
