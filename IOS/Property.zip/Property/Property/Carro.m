//
//  Carro.m
//  Property
//
//  Created by Usuário Convidado on 20/03/17.
//  Copyright © 2017 Agesandro Scarpioni. All rights reserved.
//

#import "Carro.h"

@implementation Carro

@synthesize marca,modelo,anoFabricao;
@end
