//
//  Carro.h
//  Property
//
//  Created by Usuário Convidado on 20/03/17.
//  Copyright © 2017 Agesandro Scarpioni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Carro : NSObject

@property (nonatomic, retain) NSString *marca;
@property (nonatomic, retain) NSString *modelo;
@property (nonatomic) int *anoFabricao;



@end
